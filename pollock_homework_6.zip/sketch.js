function setup() {
  createCanvas(400, 400);
    background(255);
  
  
}

function draw() {
  
  rect(0, 0, 55, 55); // Draw rect at original 0,0

translate(30, 30);
  scale(2);
  
rect(0, 0, 55, 55); // Draw rect at new 0,0
   push();
translate(40, 40);
  scale(0.5);
  fill(0);
   pop();
  
rect(0, 0, 55, 55); // Draw rect at new 0,0
  fill(0);
  translate(70, 70);
  scale(.5);
  
  
   angleMode(DEGREES); // Change the mode to DEGREES
  let a = atan2(mouseY - height / 10, mouseX - width / 10);
  translate(width / 6, height / 6);
 
  rotate(a);
 
  angleMode(RADIANS); // Change the mode to RADIANS
  rotate(a); // variable a stays the same
  translate(width / 2, height / 2);
rotate(PI / 4.0);
rect(-243, -15, 55, 55);
  
  
  for (var i = 100; i < 400; i += 60) {
rect(i, 120, i + 20, 100);

  }
  let x = 10;
  print("how many times have you cried since friday? " + x);
}