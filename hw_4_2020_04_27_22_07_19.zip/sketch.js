function setup() {
  createCanvas(400, 400);
  frameRate(100); 
 r = random(255);
  g = random(255);
  b = random(255);
   background(180);
}
function draw() {

  // Draw a circle
  strokeWeight(2);
  stroke(r, g, b);
  fill(r, g, b, 50);
  ellipse(360, 200, 200, 200);
  
  if (keyIsPressed === true) {
    fill(r, g, b, 100);
  } else {
    keyIsPressed === false;
   fill(255);
  }

  rect(25, 25, 60, 60);  
  fill(180);
  strokeWeight(6);
  stroke(r, g, b);
 
  
  
  
  
}

// When the user clicks the mouse
function mousePressed() {
  // Check if mouse is inside the circle
  let d = dist(mouseX, mouseY, 360, 200);
  if (d < 100) {
    // Pick new random color values
    r = random(255);
    g = random(255);
    b = random(255);
  }

  for (var i = 30; i < 400; i += 60) {
rect(i, 60, i + 60, 150);
  
  
}


}