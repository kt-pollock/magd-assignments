function setup() {
  createCanvas(400, 400);
  background(200);
  let fr = 60;
  frameRate(fr); 
  colorMode(RGB, 255);
let c = color;
  clr = color(60, 10, 160, 1);
  eLoc = 6
}
function draw() {
   
  let eSize = 80;
  let x1 = mouseX;
  let y1 = 80;
  let x2 = sqrt(x1);
  let y2 = mouseY

  line(mouseX, mouseY, pmouseX, pmouseY);
  print(pmouseX + ' -> ' + mouseX);
  print(pmouseY + ' -> ' + mouseY);
  

  fill(120, 200, 25, .8);
  ellipse(x2, y2, eSize, eSize);

fill(300, 20, 25, .8);
  ellipse(x1, y1, eSize, eSize);

  

 angleMode(DEGREES); // Change the mode to DEGREES
  let a = atan2(mouseY - height / 2, mouseX - width / 2);
  translate(width / 2, height / 2);
  fill(60, 10, 160, 1);
  push();
  rotate(a);
  rect(-20, -5, 40, 10); // Larger rectangle is rotating in degrees
  pop();
  angleMode(RADIANS); // Change the mode to RADIANS
  rotate(a); // variable a stays the same
  rect(-40, -5, 20, 10); // Smaller rectangle is rotating in radians
  

}